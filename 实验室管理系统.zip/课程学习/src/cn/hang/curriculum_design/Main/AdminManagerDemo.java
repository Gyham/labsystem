package cn.hang.curriculum_design.Main;

import cn.hang.curriculum_design.Component.*;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminManagerDemo {
    JFrame jf = new JFrame("实验室管理系统");


    final int WIDTH = 1200;
    final int HEIGHT = 600;


    //组装视图
    public void init() throws Exception {
        //给窗口设置属性
        jf.setBounds((ScreenUtils.getScreenWidth() - WIDTH) / 2, (ScreenUtils.getScreenHeight() - HEIGHT) / 2, WIDTH, HEIGHT);
//        jf.setBounds(0,0, ScreenUtils.getScreenWidth(), ScreenUtils.getScreenHeight());
        jf.setResizable(true);

        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //设置菜单栏
        JMenuBar jmb = new JMenuBar();
        JMenu jMenu = new JMenu("设置");
        JMenuItem m1 = new JMenuItem("切换账号");
        JMenuItem m2 = new JMenuItem("退出程序");
        m1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new LoginFrame("实验室管理系统");
                    jf.dispose();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        m2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        jMenu.add(m1);
        jMenu.add(m2);
        jmb.add(jMenu);

        jf.setJMenuBar(jmb);

        //设置分割面板
        JSplitPane sp = new JSplitPane();

        //支持连续布局
        sp.setContinuousLayout(true);
        sp.setDividerLocation(160);
        sp.setDividerSize(7);

        //设置左侧内容
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("系统管理");
        DefaultMutableTreeNode devManage = new DefaultMutableTreeNode("实验室设备管理");
        DefaultMutableTreeNode typeManage = new DefaultMutableTreeNode("实验室设备类型管理");
        DefaultMutableTreeNode regManage = new DefaultMutableTreeNode("实验室使用登记管理");
        DefaultMutableTreeNode code_listManage = new DefaultMutableTreeNode("代码列表");
        DefaultMutableTreeNode statisticsManage = new DefaultMutableTreeNode("统计分析");

        root.add(devManage);
        root.add(typeManage);
        root.add(regManage);
        root.add(code_listManage);
        root.add(statisticsManage);

        JTree tree = new JTree(root);

        //设置当前tree默认选中教职工管理
        tree.setSelectionRow(1);
        tree.addTreeSelectionListener(new TreeSelectionListener() {
            //当条目选中变化后，这个方法会执行
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                //得到当前选中的结点对象
                Object lastPathComponent = e.getNewLeadSelectionPath().getLastPathComponent();
                    if (devManage.equals(lastPathComponent)){
//                    sp.setRightComponent(new JLabel("这里进行实验室设备管理..."));
                        sp.setRightComponent(new DevManageComponent(jf));

                        sp.setDividerLocation(150);
                    }else if (typeManage.equals(lastPathComponent)){
//                    sp.setRightComponent(new JLabel("这里进行实验室设备类型管理..."));
                        sp.setRightComponent(new TypeManageComponent(jf));

                        sp.setDividerLocation(150);
                    } else if (regManage.equals(lastPathComponent)){
//                    sp.setRightComponent(new JLabel("这里进行实验室使用登记管理..."));
                        sp.setRightComponent(new RegManageComponent(jf));
                        sp.setDividerLocation(150);
                    } else if (code_listManage.equals(lastPathComponent)){
//                    sp.setRightComponent(new JLabel("这里进行代码列表..."));
                        sp.setRightComponent(new CodeListComponent(jf));
                        sp.setDividerLocation(150);
                    }else if (statisticsManage.equals(lastPathComponent)){
//                        sp.setRightComponent(new JLabel("这里进行数据统计..."));
                        sp.setRightComponent(new StatisticsManageComponentToAdmin(jf));
                        sp.setDividerLocation(150);
                    }
                }
        });

        sp.setRightComponent(new DevManageComponent(jf));//将组件设置在右侧（或更低）分隔线。
        sp.setLeftComponent(tree);
        jf.add(sp);
        jf.setVisible(true);

    }

    public static void main(String[] args) {
        try {
            new AdminManagerDemo().init();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
