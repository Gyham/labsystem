package cn.hang.curriculum_design.Main;

import cn.hang.curriculum_design.entity.UserList;
import cn.hang.curriculum_design.util.OperationUtil;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;


public class LoginFrame extends JFrame {
    public static void main(String[] args) {
        new LoginFrame("实验室管理系统");
    }

    private UserList userList;
    private JFrame frame;
    private JPanel panel;  //登录面板
    private ButtonGroup SelectButtonGroup;  //单选按钮组对象
    private JTextField accountText;
    private JPasswordField passwordText;

    private int HEIGHT = 400;
    private int WEIGH = 550;

    private int jurisdiction;

    // 新建用户对象 用于校验 账号密码


    public LoginFrame(String Title) {
        super(Title);
        userList = new UserList();
        frame = new JFrame();
        Container container = getContentPane();
        setBounds((ScreenUtils.getScreenWidth()-WEIGH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WEIGH,HEIGHT);

        panel = new JPanel();

        container.add(panel);
        //在面板上添加信息
        addLoginPanel(panel);
        setVisible(true);   //设置可见
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 设置关闭
    }


    public void addLoginPanel(JPanel panel) {

        panel.setLayout(null);
        JLabel TitleLabel = new JLabel("实验室管理系统");
        Font font = new Font("SansSerif",Font.ITALIC+Font.BOLD,40);
        TitleLabel.setFont(font);
        TitleLabel.setBounds(110,20,300,100);
        panel.add(TitleLabel);
        panel.add(TitleLabel, BorderLayout.CENTER);

        //这边设置布局为null
        panel.setLayout(null);
        JLabel userLabel = new JLabel("账号:");

        userLabel.setBounds(140, 100, 100, 90);

        //添加到面板panel中
        panel.add(userLabel, BorderLayout.CENTER);

        //创建文本域(JTextField函数) 用来创建文本域输入信息的
        accountText = new JTextField(20);
        accountText.setBounds(175, 135, 165, 25);

        //添加到面板panel中
        panel.add(accountText);


        //创建JLabel 与上面操作一样的
        JLabel passwordLabel = new JLabel("密码:");
        passwordLabel.setBounds(140, 160, 80, 25);
        panel.add(passwordLabel);

        //换个文本域创建方法 用于保护密码安全 类似上面的JTextField方法
        passwordText = new JPasswordField(20);
        passwordText.setBounds(175, 160, 165, 25);
        panel.add(passwordText);


        //创建登陆按钮(JButton)
        JButton loginButton = new JButton("登录");
//        loginButton.setBounds(165, 200, 60, 25);
        loginButton.setBounds(205, 235, 60, 25);
        panel.add(loginButton, BorderLayout.CENTER);



        loginButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               String id = accountText.getText();
               String pwd = String.valueOf(passwordText.getPassword());
               System.out.println(id+":"+pwd);
               jurisdiction = verifyLogin(id,pwd);
               try {
                   if (jurisdiction ==1){
                       new RootManagerDemo().init();
                   }else if (jurisdiction ==2){
                       new AdminManagerDemo().init();
                   }else {
                       JOptionPane.showMessageDialog(TitleLabel,"账号或密码错误,请重新输入!");
                   }
//                   new RootManagerDemo().init();
               } catch (Exception exception) {
                   exception.printStackTrace();
               }
               dispose();
           }
       });

        panel.add(loginButton);

    }

    private int verifyLogin(String id,String pwd){
        int i =-1;
        String sql = "select juris from user_list where username = ? and password = ?";
        List<Map<String, Object>> maps = OperationUtil.selData(sql, id, pwd);
        if (maps.isEmpty()){
            return i;
        }
//        System.out.println(maps.get(0));
        String str = String.valueOf(maps.get(0).values());
        System.out.println(str);

        if (str.equals("[最高级管理员]")){
            i = 1;
        }else if (str.equals("[实验室管理员]")){
            i = 2;
        }
        return i;
    }

}