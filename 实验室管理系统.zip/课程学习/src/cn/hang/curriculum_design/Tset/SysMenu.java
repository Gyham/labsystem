package cn.hang.curriculum_design.Tset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * @author GyHam
 * @date 2021 - 06 - 29 - 10:09
 */
public class SysMenu extends JFrame implements ActionListener {
    private final JMenuBar mb = new JMenuBar();
    //一级管理
    private final JMenu staMan = new JMenu("教职工管理");
    private final JMenu labMan = new JMenu("实验室管理");
    private final JMenu acaMan = new JMenu("学院信息管理");
    private final JMenu proMan = new JMenu("职称管理");
    //二级管理
    private final JMenu labMesMan = new JMenu("实验室基本信息管理");
    private final JMenu devMan = new JMenu("实验室设备管理");
    private final JMenu typeMan = new JMenu("实验室设备类型管理");
    private final JMenu regMan = new JMenu("实验室使用登记表管理");
    //二级功能
    private final JMenuItem sta_add    = new JMenuItem("添加教职工信息");
    private final JMenuItem sta_update = new JMenuItem("修改教职工信息");
    private final JMenuItem sta_delete = new JMenuItem("删除教职工信息");
    private final JMenuItem sta_select = new JMenuItem("查询教职工信息");

    private final JMenuItem aca_add    = new JMenuItem("添加学院信息");
    private final JMenuItem aca_update = new JMenuItem("修改学院信息");
    private final JMenuItem aca_delete = new JMenuItem("删除学院信息");
    private final JMenuItem aca_select = new JMenuItem("查询学院信息");

    private final JMenuItem pro_add    = new JMenuItem("添加职称信息");
    private final JMenuItem pro_update = new JMenuItem("修改职称信息");
    private final JMenuItem pro_delete = new JMenuItem("删除职称信息");
    private final JMenuItem pro_select = new JMenuItem("查询职称信息");

    //三级功能
    private final JMenuItem lab_add    = new JMenuItem("添加实验室信息");
    private final JMenuItem lab_update = new JMenuItem("修改实验室信息");
    private final JMenuItem lab_delete = new JMenuItem("删除实验室信息");
    private final JMenuItem lab_select = new JMenuItem("查询实验室信息");

    private final JMenuItem dev_add    = new JMenuItem("添加实验室设备信息");
    private final JMenuItem dev_update = new JMenuItem("修改实验室设备信息");
    private final JMenuItem dev_delete = new JMenuItem("删除实验室设备信息");
    private final JMenuItem dev_select = new JMenuItem("查询实验室设备信息");

    private final JMenuItem type_add    = new JMenuItem("添加实验室设备类型信息");
    private final JMenuItem type_update = new JMenuItem("修改实验室设备类型信息");
    private final JMenuItem type_delete = new JMenuItem("删除实验室设备类型信息");
    private final JMenuItem type_select = new JMenuItem("查询实验室设备类型信息");

    private final JMenuItem reg_add    = new JMenuItem("添加实验室使用登记表信息");
    private final JMenuItem reg_delete = new JMenuItem("修改实验室使用登记表信息");
    private final JMenuItem reg_update = new JMenuItem("删除实验室使用登记表信息");
    private final JMenuItem reg_select = new JMenuItem("查询实验室使用登记表信息");

    public SysMenu(){
        super("实验室管理系统");
        //设置为流式布局
        setLayout(new FlowLayout());

        //设置当前窗口的菜单条
        this.setJMenuBar(mb);

        //向二级菜单中添加菜单项　
        labMesMan.add(lab_add);
        labMesMan.add(lab_delete);
        labMesMan.add(lab_update);
        labMesMan.add(lab_select);

        devMan.add(dev_add);
        devMan.add(dev_delete);
        devMan.add(dev_update);
        devMan.add(dev_select);

        typeMan.add(type_add);
        typeMan.add(type_delete);
        typeMan.add(type_update);
        typeMan.add(type_select);

        regMan.add(reg_add);
        regMan.add(reg_delete);
        regMan.add(reg_update);
        regMan.add(reg_select);

        //向一级菜单中添加菜单项
        staMan.add(sta_add);
        staMan.add(sta_delete);
        staMan.add(sta_update);
        staMan.add(sta_select);

        labMan.add(labMesMan);
        labMan.add(devMan);
        labMan.add(typeMan);
        labMan.add(regMan);

        acaMan.add(aca_add);
        acaMan.add(aca_delete);
        acaMan.add(aca_update);
        acaMan.add(aca_select);

        proMan.add(pro_add);
        proMan.add(pro_delete);
        proMan.add(pro_update);
        proMan.add(pro_select);

        // 向菜单条添加菜单项
        mb.add(staMan);
        mb.add(labMan);
        mb.add(acaMan);
        mb.add(proMan);

        //注册监听器
        sta_add.addActionListener(this);
        sta_update.addActionListener(this);
        sta_delete.addActionListener(this);
        sta_select.addActionListener(this);

        aca_add.addActionListener(this);
        aca_update.addActionListener(this);
        aca_delete.addActionListener(this);
        aca_select.addActionListener(this);

        pro_add.addActionListener(this);
        pro_update.addActionListener(this);
        pro_delete.addActionListener(this);
        pro_select.addActionListener(this);


        lab_add.addActionListener(this);
        lab_update.addActionListener(this);
        lab_delete.addActionListener(this);
        lab_select.addActionListener(this);

        dev_add.addActionListener(this);
        dev_update.addActionListener(this);
        dev_delete.addActionListener(this);
        dev_select.addActionListener(this);

        type_add.addActionListener(this);
        type_update.addActionListener(this);
        type_delete.addActionListener(this);
        type_select.addActionListener(this);

        reg_add.addActionListener(this);
        reg_delete.addActionListener(this);
        reg_update.addActionListener(this);
        reg_select.addActionListener(this);

        /* 使用窗口适配器为窗口添加监听,实现关闭操作 */
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                close();  //调用close()方法来关闭
            }
        });

        this.setVisible(true);
        this.setSize(600,600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);


    }

    public void close() {    //关闭窗口的操作
        //释放此Window ，其子组件及其所有子集所使用的所有本地屏幕资源。
        this.dispose();
        System.exit(0);
    }







    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.equals("")){

        }
    }
}
