package cn.hang.curriculum_design.Tset;

import java.util.Vector;

public class Test01 {
    public static void main(String[] args)
    {
        Vector v=new Vector();
        v.addElement("abc1");
        v.addElement("abc2");
        v.addElement("abc3");
        v.addElement("abc4");

        Vector vec=new Vector();
        vec.add("abc1");
        vec.add("abc2");
        vec.add("abc3");
        vec.add("abc4");

        System.out.println(v);
        System.out.println(vec);

    }
}