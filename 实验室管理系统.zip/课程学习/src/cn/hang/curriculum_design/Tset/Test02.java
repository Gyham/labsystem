package cn.hang.curriculum_design.Tset;

/**
 * @author GyHam
 * @date 2021 - 06 - 29 - 13:53
 */
public class Test02 {
    public static void main(String[] args) {
        String sql = "star,dsarsr,sada";
        System.out.println(sql.substring(1,sql.length()));

    }
}
