package cn.hang.curriculum_design.entity;

/**
 * @author GyHam
 * @date 2021 - 06 - 28 - 9:03
 */

/**
 * 用户权限表实体
 */
public class Jurisdiction {
    private int jid;
    private int jcode;
    private String janem;
    private String jtext;

    public int getJid() {
        return jid;
    }

    public void setJid(int jid) {
        this.jid = jid;
    }

    public int getJcode() {
        return jcode;
    }

    public void setJcode(int jcode) {
        this.jcode = jcode;
    }

    public String getJanem() {
        return janem;
    }

    public void setJanem(String janem) {
        this.janem = janem;
    }

    public String getJtext() {
        return jtext;
    }

    public void setJtext(String jtext) {
        this.jtext = jtext;
    }

    @Override
    public String toString() {
        return "Jurisdiction{" +
                "jid=" + jid +
                ", jcode=" + jcode +
                ", janem='" + janem + '\'' +
                ", jtext='" + jtext + '\'' +
                '}';
    }
}
