package cn.hang.curriculum_design.entity;

/**
 * @author GyHam
 * @date 2021 - 06 - 28 - 9:02
 */

import javax.xml.crypto.Data;

/**
 * 实验室信息实体
 */
public class Lab_info {

    private int lid;
    private int lcode;
    private String lname;
    private String lsite;
    private String ltype;
    private int lare;
    private String lcontact;
    private int lseating;
    private Data lsetting;
    private String llevel;
    private int acode;

    public int getLid() {
        return lid;
    }

    public void setLid(int lid) {
        this.lid = lid;
    }

    public int getLcode() {
        return lcode;
    }

    public void setLcode(int lcode) {
        this.lcode = lcode;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getLsite() {
        return lsite;
    }

    public void setLsite(String lsite) {
        this.lsite = lsite;
    }

    public String getLtype() {
        return ltype;
    }

    public void setLtype(String ltype) {
        this.ltype = ltype;
    }

    public int getLare() {
        return lare;
    }

    public void setLare(int lare) {
        this.lare = lare;
    }

    public String getLcontact() {
        return lcontact;
    }

    public void setLcontact(String lcontact) {
        this.lcontact = lcontact;
    }

    public int getLseating() {
        return lseating;
    }

    public void setLseating(int lseating) {
        this.lseating = lseating;
    }

    public Data getLsetting() {
        return lsetting;
    }

    public void setLsetting(Data lsetting) {
        this.lsetting = lsetting;
    }

    public String getLlevel() {
        return llevel;
    }

    public void setLlevel(String llevel) {
        this.llevel = llevel;
    }

    public int getAcode() {
        return acode;
    }

    public void setAcode(int acode) {
        this.acode = acode;
    }

    @Override
    public String toString() {
        return "Lab_info{" +
                "lid=" + lid +
                ", lcode=" + lcode +
                ", lname='" + lname + '\'' +
                ", lsite='" + lsite + '\'' +
                ", ltype='" + ltype + '\'' +
                ", lare=" + lare +
                ", lcontact='" + lcontact + '\'' +
                ", lseating=" + lseating +
                ", lsetting=" + lsetting +
                ", llevel='" + llevel + '\'' +
                ", acode=" + acode +
                '}';
    }
}
