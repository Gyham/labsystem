package cn.hang.curriculum_design.entity;

/**
 * @author GyHam
 * @date 2021 - 06 - 28 - 9:05
 */

/**
 * 实验设备类型实体
 */
public class Lab_dev_type {
    private int tid;
    private int tcode;
    private String tname;
    private int snum;

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

    public int getTcode() {
        return tcode;
    }

    public void setTcode(int tcode) {
        this.tcode = tcode;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public int getSnum() {
        return snum;
    }

    public void setSnum(int snum) {
        this.snum = snum;
    }

    @Override
    public String toString() {
        return "Lab_dev_type{" +
                "tid=" + tid +
                ", tcode=" + tcode +
                ", tname='" + tname + '\'' +
                ", snum=" + snum +
                '}';
    }
}
