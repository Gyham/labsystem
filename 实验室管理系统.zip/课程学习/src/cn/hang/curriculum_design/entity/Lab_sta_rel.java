package cn.hang.curriculum_design.entity;

/**
 * @author GyHam
 * @date 2021 - 06 - 28 - 9:06
 */

/**
 * 实验室-教职工关系实体
 */
public class Lab_sta_rel {
    private int ls_id;
    private int lcode;
    private int snum;

    public int getLs_id() {
        return ls_id;
    }

    public void setLs_id(int ls_id) {
        this.ls_id = ls_id;
    }

    public int getLcode() {
        return lcode;
    }

    public void setLcode(int lcode) {
        this.lcode = lcode;
    }

    public int getSnum() {
        return snum;
    }

    public void setSnum(int snum) {
        this.snum = snum;
    }

    @Override
    public String toString() {
        return "reg_sta_rel{" +
                "ls_id=" + ls_id +
                ", lcode=" + lcode +
                ", snum=" + snum +
                '}';
    }
}
