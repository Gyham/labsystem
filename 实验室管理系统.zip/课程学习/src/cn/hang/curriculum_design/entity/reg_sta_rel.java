package cn.hang.curriculum_design.entity;

/**
 * @author GyHam
 * @date 2021 - 06 - 28 - 9:16
 */

/**
 * 实验室使用登记表-教职工关系实体
 */
public class reg_sta_rel {
    private int rs_id;
    private int rcode;
    private int snum;

    public int getRs_id() {
        return rs_id;
    }

    public void setRs_id(int rs_id) {
        this.rs_id = rs_id;
    }

    public int getRcode() {
        return rcode;
    }

    public void setRcode(int rcode) {
        this.rcode = rcode;
    }

    public int getSnum() {
        return snum;
    }

    public void setSnum(int snum) {
        this.snum = snum;
    }

    @Override
    public String toString() {
        return "reg_sta_rel{" +
                "rs_id=" + rs_id +
                ", rcode=" + rcode +
                ", snum=" + snum +
                '}';
    }
}
