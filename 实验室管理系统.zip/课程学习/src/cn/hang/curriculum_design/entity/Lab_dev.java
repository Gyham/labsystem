package cn.hang.curriculum_design.entity;

/**
 * @author GyHam
 * @date 2021 - 06 - 28 - 9:04
 */

import javax.xml.crypto.Data;

/**
 * 实验设备实体
 */
public class Lab_dev {
    private int eid;
    private int ecode;
    private String ename;
    private String espec;
    private int equan;
    private Data etime;
    private int tcode;
    private int lcode;

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public int getEcode() {
        return ecode;
    }

    public void setEcode(int ecode) {
        this.ecode = ecode;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public String getEspec() {
        return espec;
    }

    public void setEspec(String espec) {
        this.espec = espec;
    }

    public int getEquan() {
        return equan;
    }

    public void setEquan(int equan) {
        this.equan = equan;
    }

    public Data getEtime() {
        return etime;
    }

    public void setEtime(Data etime) {
        this.etime = etime;
    }

    public int getTcode() {
        return tcode;
    }

    public void setTcode(int tcode) {
        this.tcode = tcode;
    }

    public int getLcode() {
        return lcode;
    }

    public void setLcode(int lcode) {
        this.lcode = lcode;
    }

    @Override
    public String toString() {
        return "Lab_dev{" +
                "eid=" + eid +
                ", ecode=" + ecode +
                ", ename='" + ename + '\'' +
                ", espec='" + espec + '\'' +
                ", equan=" + equan +
                ", etime=" + etime +
                ", tcode=" + tcode +
                ", lcode=" + lcode +
                '}';
    }
}
