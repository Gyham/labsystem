package cn.hang.curriculum_design.entity;

/**
 * @author GyHam
 * @date 2021 - 06 - 28 - 9:15
 */

/**
 * 职称表实体
 */
public class pro_title {
    private int pid;
    private int pcode;
    private String pname;

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public int getPcode() {
        return pcode;
    }

    public void setPcode(int pcode) {
        this.pcode = pcode;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    @Override
    public String toString() {
        return "pro_title{" +
                "pid=" + pid +
                ", pcode=" + pcode +
                ", pname='" + pname + '\'' +
                '}';
    }
}
