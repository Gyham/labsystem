package cn.hang.curriculum_design.entity;

/**
 * @author GyHam
 * @date 2021 - 06 - 28 - 9:09
 */

import javax.xml.crypto.Data;

/**
 * 实验室使用登记表实体
 */

public class Lab_use_reg {
    private int rid;
    private int rcode;
    private Data rtime;
    private String rcase;
    private int lcode;
    private int snum;

    public int getRid() {
        return rid;
    }

    public void setRid(int rid) {
        this.rid = rid;
    }

    public int getRcode() {
        return rcode;
    }

    public void setRcode(int rcode) {
        this.rcode = rcode;
    }

    public Data getRtime() {
        return rtime;
    }

    public void setRtime(Data rtime) {
        this.rtime = rtime;
    }

    public String getRcase() {
        return rcase;
    }

    public void setRcase(String rcase) {
        this.rcase = rcase;
    }

    public int getLcode() {
        return lcode;
    }

    public void setLcode(int lcode) {
        this.lcode = lcode;
    }

    public int getSnum() {
        return snum;
    }

    public void setSnum(int snum) {
        this.snum = snum;
    }

    @Override
    public String toString() {
        return "Lab_use_reg{" +
                "rid=" + rid +
                ", rcode=" + rcode +
                ", rtime=" + rtime +
                ", rcase='" + rcase + '\'' +
                ", lcode=" + lcode +
                ", snum=" + snum +
                '}';
    }
}
