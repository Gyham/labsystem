package cn.hang.curriculum_design.entity;

/**
 * @author GyHam
 * @date 2021 - 06 - 28 - 9:03
 */

/**
 * 学院信息实体
 */
public class Aca_info {
    private int aid;
    private int acode;
    private String aname;
    private String asite;
    private String acontact;

    public int getAid() {
        return aid;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }

    public int getAcode() {
        return acode;
    }

    public void setAcode(int acode) {
        this.acode = acode;
    }

    public String getAname() {
        return aname;
    }

    public void setAname(String aname) {
        this.aname = aname;
    }

    public String getAsite() {
        return asite;
    }

    public void setAsite(String asite) {
        this.asite = asite;
    }

    public String getAcontact() {
        return acontact;
    }

    public void setAcontact(String acontact) {
        this.acontact = acontact;
    }

    @Override
    public String toString() {
        return "Aca_info{" +
                "aid=" + aid +
                ", acode=" + acode +
                ", aname='" + aname + '\'' +
                ", asite='" + asite + '\'' +
                ", acontact='" + acontact + '\'' +
                '}';
    }
}
