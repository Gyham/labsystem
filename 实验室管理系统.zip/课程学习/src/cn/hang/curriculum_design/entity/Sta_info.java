package cn.hang.curriculum_design.entity;

/**
 * @author GyHam
 * @date 2021 - 06 - 28 - 9:17
 */

/**
 * 教职工实体
 */
public class Sta_info {
    private int sid;
    private int snum;
    private String sname;
    private String ssex;
    private int sage;
    private String scontact;
    private int staff_id;
    private String staff_pwd;
    private int pcode;
    private int jcode;
    private int acode;

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getSnum() {
        return snum;
    }

    public void setSnum(int snum) {
        this.snum = snum;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSsex() {
        return ssex;
    }

    public void setSsex(String ssex) {
        this.ssex = ssex;
    }

    public int getSage() {
        return sage;
    }

    public void setSage(int sage) {
        this.sage = sage;
    }

    public String getScontact() {
        return scontact;
    }

    public void setScontact(String scontact) {
        this.scontact = scontact;
    }

    public int getStaff_id() {
        return staff_id;
    }

    public void setStaff_id(int staff_id) {
        this.staff_id = staff_id;
    }

    public String getStaff_pwd() {
        return staff_pwd;
    }

    public void setStaff_pwd(String staff_pwd) {
        this.staff_pwd = staff_pwd;
    }

    public int getPcode() {
        return pcode;
    }

    public void setPcode(int pcode) {
        this.pcode = pcode;
    }

    public int getJcode() {
        return jcode;
    }

    public void setJcode(int jcode) {
        this.jcode = jcode;
    }

    public int getAcode() {
        return acode;
    }

    public void setAcode(int acode) {
        this.acode = acode;
    }

    @Override
    public String toString() {
        return "Sta_info{" +
                "sid=" + sid +
                ", snum=" + snum +
                ", sname='" + sname + '\'' +
                ", ssex='" + ssex + '\'' +
                ", sage=" + sage +
                ", scontact='" + scontact + '\'' +
                ", staff_id=" + staff_id +
                ", staff_pwd='" + staff_pwd + '\'' +
                ", pcode=" + pcode +
                ", jcode=" + jcode +
                ", acode=" + acode +
                '}';
    }
}
