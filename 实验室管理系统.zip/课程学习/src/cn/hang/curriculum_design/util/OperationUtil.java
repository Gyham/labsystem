package cn.hang.curriculum_design.util;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.lang.NonNull;

import java.util.List;
import java.util.Map;
import java.util.Vector;

/**
 * @author GyHam
 * @date 2021 - 06 - 29 - 8:27
 */
public class OperationUtil {
    //1.获取JdbcTemplate对象
    private static JdbcTemplate template = new JdbcTemplate(JDBCUtil.getDataSource());

    private String DML;
    private static int count;
    private static Vector<Vector> vectors = null;

    //修改数据
    public static int upData(String sql,@NonNull Object... vag){
        int count = template.update(sql,vag);
        return count;
    }

    //删除数据
    public static int deData(String sql,@NonNull Object... vag){
        int count = template.update(sql,vag);
        return count;
    }

    //插入数据
    public static int inData(String sql,@NonNull Object... vag){
        int count = template.update(sql,vag);
        return count;
    }

    //查询数据,返回list
    public static List<Map<String, Object>> selData(String sql,@NonNull Object... vag){
        //执行sql
        List<Map<String, Object>> list = template.queryForList(sql,vag);
        //iter 迭代
//        for (Map<String, Object> stringObjectMap : list) {
//            System.out.println(stringObjectMap.values());
//        }
        return list;
    }

    //查询总记录数(用于聚合函数)
    public static long statiData(String sql,@NonNull Object... vag){
        long total = template.queryForObject(sql,vag,long.class);
        return total;
    }




}
