package cn.hang.curriculum_design.util;

import org.springframework.lang.NonNull;

import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.Map;
import java.util.Vector;

/**
 * @author GyHam
 * @date 2021 - 06 - 29 - 17:33
 */
public class ToolUtil {
    private static Map<String, Object> map;

    public static void requestData(String sql,DefaultTableModel tableModel, Vector<String> titles, Vector<Vector> tableData) {
        List<Map<String, Object>> maps = OperationUtil.selData(sql);
        Vector<Vector> vectors = VectorUtil.convertListDataVector(maps);

        //清空tableData的数据
        tableData.clear();

        for (Vector vector : vectors) {
            tableData.add(vector);
//            System.out.println(vector);
        }

        //刷新表格
        tableModel.fireTableStructureChanged();
    }

    public static void requestSingeData(String sql,DefaultTableModel tableModel, Vector<String> titles, Vector<Vector> tableData,@NonNull Object... vag) {
        List<Map<String, Object>> maps = OperationUtil.selData(sql,vag);
        Vector<Vector> vectors = VectorUtil.convertListDataVector(maps);
        //清空tableData的数据
        tableData.clear();
        for (Vector vector : vectors) {
            tableData.addElement(vector);
        }

        //刷新表格
        tableModel.fireTableDataChanged();
    }
}
