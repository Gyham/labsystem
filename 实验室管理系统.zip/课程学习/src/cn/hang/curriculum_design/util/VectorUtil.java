package cn.hang.curriculum_design.util;

import java.util.List;
import java.util.Map;
import java.util.Vector;

/**
 * @author GyHam
 * @date 2021 - 06 - 29 - 13:58
 */
public class VectorUtil {

    private static Vector<Vector> vectors = null;
    private static Vector vector = null;
    public static Vector<Vector> convertListDataVector(List<Map<String, Object>> list){
        vectors = new Vector<>();
        for (Map<String, Object> map : list) {
            vector = new Vector();
            vector.addAll(map.values());
            vectors.add(vector);
//            System.out.println(vectors);
        }
        return vectors;
    }

 /*   public static Vector<Vector> convertMapsDataVector(Map<String, Object> maps){
        vectors = new Vector<>();
        vector.addAll(maps.values());
        vectors.add(vector);
        return vectors;
    }*/
}
