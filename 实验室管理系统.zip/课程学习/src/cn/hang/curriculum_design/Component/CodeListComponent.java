package cn.hang.curriculum_design.Component;


import cn.hang.curriculum_design.util.ToolUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

public class CodeListComponent extends Box {
    final int WIDTH=1050;
    final int HEIGHT=600;
    JFrame jf = null;
    private JTable table;
    private Vector<String> titles;
    private Vector<Vector> tableData;
    private DefaultTableModel tableModel;

    public CodeListComponent(JFrame jf){
        //垂直布局
        super(BoxLayout.Y_AXIS);
        //组装视图
        this.jf = jf;
        JPanel btnPanel = new JPanel();
//        Color color = new Color(203,220,217);
//        btnPanel.setBackground(color);
        btnPanel.setMaximumSize(new Dimension(WIDTH,80));
        btnPanel.setVisible(true);
        btnPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

        JButton staBtn = new JButton("教职工代码");
        JButton labBtn = new JButton("实验室代码");
        JButton devBtn = new JButton("设备代码");
        JButton typeBtn = new JButton("设备类型代码");
        JButton regBtn = new JButton("登记表代码");
        JButton acaBtn = new JButton("学院代码");
        JButton proBtn = new JButton("职称代码");

        proBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String sql = "select pcode,pname from pro_title";
                requestData(sql);
            }
        });

        acaBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String sql = "select acode,aname from aca_info";
                requestData(sql);
            }
        });

        staBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //输出数据
//                String[] ts = {"职工号","姓名"};
                String sql = "select snum,sname from sta_info";
                requestData(sql);
            }
        });

        labBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //输出数据
//                String [] ts = {"实验室代码","实验室名称"};
                String sql = "select lcode,lname from lab_info";
                requestData(sql);
            }
        });

        devBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //输出数据
//                String [] ts = {"设备代码","设备名称"};
                String sql = "select ecode,ename from lab_dev";
                requestData(sql);
            }
        });

        typeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //输出数据
//                String [] ts = {"设备类型代码","设备类型名称"};
                String sql = "select tcode,tname from lab_dev_type";
                requestData(sql);
            }
        });

        regBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //输出数据
//                String [] ts = {"登记表代码","登记表所属实验室"};
                String sql = "select rcode,lname from reg_view";
                requestData(sql);
            }
        });

        btnPanel.add(staBtn);
        btnPanel.add(labBtn);
        btnPanel.add(devBtn);
        btnPanel.add(typeBtn);
        btnPanel.add(regBtn);
        btnPanel.add(acaBtn);
        btnPanel.add(proBtn);
        this.add(btnPanel);

        String[] ts = {"代码","名称"};
        titles = new Vector<>();
        for (String title : ts) {
            titles.add(title);
        }
        tableData = new Vector<>();
        tableModel = new DefaultTableModel(tableData,titles);
        table = new JTable(tableModel){
            @Override
            public boolean isCellEditable(int row, int column) {
                //不能编辑
                return false;
            }
        };
        //设置只能选中一行
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        this.add(scrollPane);



    }

    private void  requestData(String sql){
        //将数据刷新到面板上
        ToolUtil.requestData(sql,tableModel,titles,tableData);
    }

}
