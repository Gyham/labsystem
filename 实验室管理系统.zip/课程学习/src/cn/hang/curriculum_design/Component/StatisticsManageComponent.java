package cn.hang.curriculum_design.Component;



import cn.hang.curriculum_design.entity.Sta_info;
import cn.hang.curriculum_design.util.OperationUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Vector;

public class StatisticsManageComponent extends Box {
    final int WIDTH=1050;
    final int HEIGHT=600;

    JFrame jf = null;
    private JTable table;
    private Vector<String> titles;
    private Vector<Vector> tableData;
    private DefaultTableModel tableModel;
    private Sta_info sta_info;

    public StatisticsManageComponent(JFrame jf){
        //垂直布局
        super(BoxLayout.Y_AXIS);
        //组装视图
        this.jf = jf;
        JPanel btnPanel = new JPanel();
//        Color color = new Color(203,220,217);
//        btnPanel.setBackground(color);
        btnPanel.setMaximumSize(new Dimension(WIDTH,80));
        btnPanel.setVisible(true);
        btnPanel.setLayout(new FlowLayout(FlowLayout.CENTER));


        //查询教职工总数
        String staSql = "select count(snum) from sta_info";
        long staLong = OperationUtil.statiData(staSql);
//        System.out.println("staLong:"+staLong);

        //查询实验室总数
        String labSql = "select count(lcode) from lab_info";
        long labLong = OperationUtil.statiData(labSql);
//        System.out.println("labLong:"+labLong);

        //查询实验设备条数
        String devSql = "select count(ecode) from lab_dev";
        long devLong = OperationUtil.statiData(devSql);
//        System.out.println("devLong:"+devLong);

        //查询实验设备类型总数
        String typeSql = "select count(tcode) from lab_dev_type";
        long typeLong = OperationUtil.statiData(typeSql);
//        System.out.println("typeLong:"+typeLong);

        //查询实验室实验登记表总数
        String regSql = "select count(rcode) from lab_use_reg";
        long regLong = OperationUtil.statiData(regSql);
//        System.out.println("regLong:"+regLong);

        //查询用户表总数
        String userSql = "select count(username) from user_list";
        long userLong = OperationUtil.statiData(userSql);
//        System.out.println("userLong:"+userLong);



        this.add(btnPanel);

        //组装表格
        String[] ts = {"教职工总数","实验室总数","实验设备条数","实验设备类型总数","实验室实验登记表总数","用户表总数"};
        titles = new Vector<>();
        for (String title : ts) {
            titles.add(title);
        }
        Vector<String> list = new Vector<String>();

        list.add(String.valueOf(staLong));
        list.add(String.valueOf(labLong));
        list.add(String.valueOf(devLong));
        list.add(String.valueOf(typeLong));
        list.add(String.valueOf(regLong));
        list.add(String.valueOf(userLong));

        tableData = new Vector<>();

        tableModel = new DefaultTableModel(tableData,titles);
        table = new JTable(tableModel){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        //设置只能选中一行
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        this.add(scrollPane);

        tableData.clear();
        tableData.add(list);
        tableModel.fireTableStructureChanged();
    }

}
