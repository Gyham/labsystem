package cn.hang.curriculum_design.Component;


import cn.hang.curriculum_design.entity.Lab_use_reg;
import cn.hang.curriculum_design.function.RegAddDialog;
import cn.hang.curriculum_design.function.RegSelectDialog;
import cn.hang.curriculum_design.function.RegUpdateDialog;
import cn.hang.curriculum_design.util.OperationUtil;
import cn.hang.curriculum_design.util.ToolUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class RegManageComponent extends Box {
    final int WIDTH=1050;
    final int HEIGHT=600;

    JFrame jf = null;
    private JTable table;
    private Vector<String> titles;
    private Vector<Vector> tableData;
    private DefaultTableModel tableModel;
    private Lab_use_reg reg;

    public RegManageComponent(JFrame jf){
        //垂直布局
        super(BoxLayout.Y_AXIS);
        //组装视图
        this.jf = jf;
        JPanel btnPanel = new JPanel();
//        Color color = new Color(203,220,217);
//        btnPanel.setBackground(color);
        btnPanel.setMaximumSize(new Dimension(WIDTH,80));
        btnPanel.setVisible(true);
        btnPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

        JButton addBtn = new JButton("添加");
        JButton updateBtn = new JButton("修改");
        JButton deleteBtn = new JButton("删除");
        JButton refreshBtn = new JButton("刷新");
        JButton selectBtn = new JButton("查询");

        selectBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reg = new Lab_use_reg();
                new RegSelectDialog(jf,"查询实验室使用登记表信息", true,reg).setVisible(true);
                int rcode = reg.getRcode();
                String sql = "select * from reg_view where rcode = ?";
                List<Map<String, Object>> maps = OperationUtil.selData(sql, rcode);
                if (!maps.isEmpty()){
                    //查询成功
                    JOptionPane.showMessageDialog(jf,"查询成功!手动刷新返回!");
                    ToolUtil.requestSingeData(sql,tableModel,titles,tableData,rcode);
                }else {
                    //查询失败
                    JOptionPane.showMessageDialog(jf,"您输入的管理员代码不存在!");

                }
            }
        });

        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //弹出一个对话框，让用户输入教职工的信息
                new RegAddDialog(jf,"添加实验室使用登记信息", true).setVisible(true);
                requestData();
            }
        });

        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取当前表格选中的id
                int selectedRow = table.getSelectedRow();//如果有选中的条目，则返回条目的行号，如果没有选中，那么返回-1

                if (selectedRow==-1){
                    JOptionPane.showMessageDialog(jf,"请选择要修改的条目！");
                    return;
                }
                String id = tableModel.getValueAt(selectedRow, 0).toString();
                //弹出一个对话框，让用户修改
                new RegUpdateDialog(jf, "修改实验室使用登记信息", true,id).setVisible(true);
                requestData();
            }
        });

        deleteBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //获取选中的条目
                int selectedRow = table.getSelectedRow();//如果有选中的条目，则返回条目的行号，如果没有选中，那么返回-1

                if (selectedRow==-1){
                    JOptionPane.showMessageDialog(jf,"请选择要删除的条目！");
                    return;
                }

                //防止误操作
                int result = JOptionPane.showConfirmDialog(jf, "确认要删除选中的条目吗？", "确认删除", JOptionPane.YES_NO_OPTION);
                if (result != JOptionPane.YES_OPTION){
                    return;
                }

                String id = tableModel.getValueAt(selectedRow, 0).toString();
                String sql = "delete from lab_use_reg where rcode = ?";
                int count = OperationUtil.deData(sql,id);
                if (count!=0){
                    //删除成功
                    JOptionPane.showMessageDialog(jf,"删除成功!");
                    requestData();
                }else {
                    //删除失败
                    JOptionPane.showMessageDialog(jf,"删除失败!");

                }
            }
        });

        //刷新功能
        refreshBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                requestData();
            }
        });

        btnPanel.add(refreshBtn);
        btnPanel.add(addBtn);
        btnPanel.add(deleteBtn);
        btnPanel.add(updateBtn);
        btnPanel.add(selectBtn);


        this.add(btnPanel);

        //组装表格
        String[] ts = {"登记表代码","使用日期","使用情况","使用人","实验室名称"};
        titles = new Vector<>();
        for (String title : ts) {
            titles.add(title);
        }

        tableData = new Vector<>();

        tableModel = new DefaultTableModel(tableData,titles);
        table = new JTable(tableModel){
            @Override
            public boolean isCellEditable(int row, int column) {
                //不能编辑
                return false;
            }
        };
        //设置只能选中一行
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        this.add(scrollPane);

        requestData();
    }
    private void  requestData(){
        String sql = "select * from reg_view";
        //将数据刷新到面板上
        ToolUtil.requestData(sql,tableModel,titles,tableData);
    }

}
