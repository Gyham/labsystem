package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.entity.UserList;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserSelectDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 150;
    private UserList userList;

    private JTextField usernameField;



    public UserSelectDialog(JFrame jf, String title, boolean isModel,UserList userList){
        super(jf,title,isModel);
        this.userList = userList;
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装职工号
        Box usernameBox = Box.createHorizontalBox();
        JLabel usernameLable = new JLabel("用户账号：");
        usernameField = new JTextField(20);

        usernameBox.add(usernameLable);
        usernameBox.add(Box.createHorizontalStrut(20));
        usernameBox.add(usernameField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton selectBtn = new JButton("查询");
        selectBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (!usernameField.getText().trim().equals("")){
                    String username = usernameField.getText().trim();
                    userList.setUsername(username);
                }
                dispose();
            }
        });
        //TODO 处理行为
        btnBox.add(selectBtn);

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(usernameBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);

    }

}
