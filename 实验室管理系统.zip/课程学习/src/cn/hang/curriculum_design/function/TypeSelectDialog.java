package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.entity.Lab_dev_type;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TypeSelectDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 150;

    private JTextField tnameField;
    private Lab_dev_type type;

    public TypeSelectDialog(JFrame jf, String title, boolean isModel,Lab_dev_type type){
        super(jf,title,isModel);
        this.type = type;
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装类型名称
        Box tnameBox = Box.createHorizontalBox();
        JLabel tnameLable = new JLabel("设备类型名称：");
        tnameField = new JTextField(15);

        tnameBox.add(tnameLable);
        tnameBox.add(Box.createHorizontalStrut(0));
        tnameBox.add(tnameField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton addBtn = new JButton("查询");
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (!tnameField.getText().trim().equals("")){
                    String tname = tnameField.getText().trim();
                    type.setTname(tname);
                }
                dispose();
            }
        });

        //TODO 处理添加的行为
        btnBox.add(addBtn);

        vBox.add(Box.createVerticalStrut(25));
        vBox.add(tnameBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);
    }
}
