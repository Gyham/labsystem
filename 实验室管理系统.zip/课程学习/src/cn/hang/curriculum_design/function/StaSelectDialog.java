package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.entity.Sta_info;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

public class StaSelectDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 150;
    private Vector<String> titles = null;
    private Vector<Vector> tableData = null;
    private DefaultTableModel tableModel = null;
//    private Sta_info sta_info;
    private JTextField snameField;


    public StaSelectDialog(JFrame jf, String title, boolean isModel,Sta_info sta_info){
        super(jf,title,isModel);
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装姓名
        Box snameBox = Box.createHorizontalBox();
        JLabel snameLable = new JLabel("姓名：");
        snameField = new JTextField(15);
        snameField.setPreferredSize(new Dimension(1,1 ));
//        snameField.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,20,20);

        snameBox.add(snameLable);
        snameBox.add(Box.createHorizontalStrut(32));
        snameBox.add(snameField);


        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton selcetBtn = new JButton("查询");
        selcetBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (!snameField.getText().trim().equals("")){
                    String sname = snameField.getText().trim();
                    sta_info.setSname(sname);
                }
                dispose();
            }
        });


        btnBox.add(selcetBtn);

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(snameBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);

    }
}
