package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.entity.Lab_info;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LabSelectDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 150;

    private Lab_info lab;

    private JTextField lcodeField;


    public LabSelectDialog(JFrame jf, String title, boolean isModel,Lab_info lab){
        super(jf,title,isModel);
        this.lab = lab;
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);
        Box vBox = Box.createVerticalBox();

        //组装代码
        Box lcodeBox = Box.createHorizontalBox();
        JLabel lcodeLable = new JLabel("实验室代码：");
        lcodeField = new JTextField(15);

        lcodeBox.add(lcodeLable);
        lcodeBox.add(Box.createHorizontalStrut(2));
        lcodeBox.add(lcodeField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton selectBtn = new JButton("查询");
        selectBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (!lcodeField.getText().trim().equals("")) {
                    Integer lcode = Integer.parseInt(lcodeField.getText().trim());
                    lab.setLcode(lcode);
                }
                dispose();
            }
        });

        //TODO 处理行为
        btnBox.add(selectBtn);

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(lcodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);
    }
}
