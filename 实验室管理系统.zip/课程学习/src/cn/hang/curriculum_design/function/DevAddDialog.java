package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.util.OperationUtil;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class DevAddDialog extends JDialog {
    final int WIDTH = 700;
    final int HEIGHT = 400;

    private JTextField ecodeField;
    private JTextField enameField;
    private JTextField especField;
    private JTextField equanField;
    private JTextField etimeField;
    private JTextField lcodeField;
    private JTextField tcodeField;

    public DevAddDialog(JFrame jf, String title, boolean isModel){
        super(jf,title,isModel);
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装代码
        Box ecodeBox = Box.createHorizontalBox();
        JLabel ecodeLable = new JLabel("设备代码：");
        ecodeField = new JTextField(15);

        ecodeBox.add(ecodeLable);
        ecodeBox.add(Box.createHorizontalStrut(10));
        ecodeBox.add(ecodeField);

        //组装名称
        Box enameBox = Box.createHorizontalBox();
        JLabel enameLable = new JLabel("设备名称：");
        enameField = new JTextField(15);

        enameBox.add(enameLable);
        enameBox.add(Box.createHorizontalStrut(10));
        enameBox.add(enameField);

        //组装型号
        Box especBox = Box.createHorizontalBox();
        JLabel especLable = new JLabel("设备型号：");
        especField = new JTextField(15);

        especBox.add(especLable);
        especBox.add(Box.createHorizontalStrut(10));
        especBox.add(especField);

        //组装数量
        Box equanBox = Box.createHorizontalBox();
        JLabel equanLable = new JLabel("设备数量：");
        equanField = new JTextField(15);

        equanBox.add(equanLable);
        equanBox.add(Box.createHorizontalStrut(10));
        equanBox.add(equanField);

        //组装购置时间
        Box etimeBox = Box.createHorizontalBox();
        JLabel etimeLable = new JLabel("购置时间：");
        etimeField = new JTextField(15);

        etimeBox.add(etimeLable);
        etimeBox.add(Box.createHorizontalStrut(10));
        etimeBox.add(etimeField);

        //组装实验室代码
        Box lcodeBox = Box.createHorizontalBox();
        JLabel lcodeLable = new JLabel("实验室代码：");
        lcodeField = new JTextField(15);

        lcodeBox.add(lcodeLable);
        lcodeBox.add(Box.createHorizontalStrut(2));
        lcodeBox.add(lcodeField);

        //组装类型代码
        Box tcodeBox = Box.createHorizontalBox();
        JLabel tcodeLable = new JLabel("设备类型代码：");
        tcodeField = new JTextField(15);

        tcodeBox.add(tcodeLable);
        tcodeBox.add(Box.createHorizontalStrut(0));
        tcodeBox.add(tcodeField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton adddateBtn = new JButton("添加");
        adddateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (ecodeField.getText().trim().equals("") || enameField.getText().trim().equals("") || especField.getText().trim().equals("") || equanField.getText().trim().equals("") || etimeField.getText().trim().equals("") || lcodeField.getText().trim().equals("")|| tcodeField.getText().trim().equals("")){
                    JOptionPane.showMessageDialog(jf,"输入有误,请重试!");
                }else {
                    Integer ecode = Integer.parseInt(ecodeField.getText().trim());
                    String ename = enameField.getText().trim();
                    String espec = especField.getText().trim();
                    Integer equan = Integer.parseInt(equanField.getText().trim());
                    String etime = etimeField.getText().trim();
                    Integer lcode = Integer.parseInt(lcodeField.getText().trim());
                    Integer tcode = Integer.parseInt(tcodeField.getText().trim());

                    Map<String,Object> maps = new HashMap<>();
                    maps.put("ecode",ecode);
                    maps.put("ename",ename);
                    maps.put("espec",espec);
                    maps.put("equan",equan);
                    maps.put("etime",etime);
                    maps.put("lcode",lcode);
                    maps.put("tcode",tcode);

                    String sql = "insert into lab_dev values(?,?,?,?,?,?,?)";
                    int count = OperationUtil.inData(sql, ecode, ename, espec, equan, etime, lcode, tcode);
                    if (count!=0){
                        //修改成功
                        JOptionPane.showMessageDialog(jf,"添加成功!");

                    }else {
                        //修改失败
                        JOptionPane.showMessageDialog(jf,"添加失败!");

                    }
                }
                dispose();

            }
        });

        //添加行为
        btnBox.add(adddateBtn);

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(ecodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(enameBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(especBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(equanBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(etimeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(lcodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(tcodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);
    }
}
