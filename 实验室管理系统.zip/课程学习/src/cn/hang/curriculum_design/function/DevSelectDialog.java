package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.entity.Lab_dev;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DevSelectDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 150;
    private Lab_dev dev;

    private JTextField ecodeField;


    public DevSelectDialog(JFrame jf, String title, boolean isModel, Lab_dev dev){
        super(jf,title,isModel);
        this.dev = dev;
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装代码
        Box ecodeBox = Box.createHorizontalBox();
        JLabel ecodeLable = new JLabel("设备代码：");
        ecodeField = new JTextField(15);

        ecodeBox.add(ecodeLable);
        ecodeBox.add(Box.createHorizontalStrut(10));
        ecodeBox.add(ecodeField);


        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton selectBtn = new JButton("查询");
        selectBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (!ecodeField.getText().trim().equals("")){
                    Integer ecode = Integer.parseInt(ecodeField.getText().trim());
                    dev.setEcode(ecode);
                }
                dispose();

            }
        });

        //TODO 处理修改的行为
        btnBox.add(selectBtn);

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(ecodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);
    }
}
