package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.util.OperationUtil;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;

public class StaAddDialog extends JDialog {
    final int WIDTH = 700;
    final int HEIGHT = 400;


    public StaAddDialog(JFrame jf, String title, boolean isModel){
        super(jf,title,isModel);
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装职工号
        Box snumBox = Box.createHorizontalBox();
        JLabel snumLable = new JLabel("职工号：");
        JTextField snumField = new JTextField(20);

        snumBox.add(snumLable);
        snumBox.add(Box.createHorizontalStrut(20));
        snumBox.add(snumField);

        //组装姓名
        Box snameBox = Box.createHorizontalBox();
        JLabel snameLable = new JLabel("姓名：");
        JTextField snameField = new JTextField(15);

        snameBox.add(snameLable);
        snameBox.add(Box.createHorizontalStrut(32));
        snameBox.add(snameField);

        //组装性别
        Box ssexBox = Box.createHorizontalBox();
        JLabel ssexLable = new JLabel("性别：");
        JTextField ssexField = new JTextField(15);

        ssexBox.add(ssexLable);
        ssexBox.add(Box.createHorizontalStrut(32));
        ssexBox.add(ssexField);

        //组装年龄
        Box sageBox = Box.createHorizontalBox();
        JLabel sageLable = new JLabel("年龄：");
        JTextField sageField = new JTextField(15);

        sageBox.add(sageLable);
        sageBox.add(Box.createHorizontalStrut(32));
        sageBox.add(sageField);

        //组装联系方式
        Box scontactBox = Box.createHorizontalBox();
        JLabel scontactLable = new JLabel("联系方式：");
        JTextField scontactField = new JTextField(15);

        scontactBox.add(scontactLable);
        scontactBox.add(Box.createHorizontalStrut(10));
        scontactBox.add(scontactField);

        //组装职称代码
        Box pcodeBox = Box.createHorizontalBox();
        JLabel pcodeLable = new JLabel("职称代码：");
        JTextField pcodeField = new JTextField(15);

        pcodeBox.add(pcodeLable);
        pcodeBox.add(Box.createHorizontalStrut(10));
        pcodeBox.add(pcodeField);


        //组装学院代码
        Box acodeBox = Box.createHorizontalBox();
        JLabel acodeLable = new JLabel("学院代码：");
        JTextField acodeField = new JTextField(15);

        acodeBox.add(acodeLable);
        acodeBox.add(Box.createHorizontalStrut(10));
        acodeBox.add(acodeField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton addBtn = new JButton("添加");
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (snumField.getText().trim().equals("") || snameField.getText().trim().equals("") || ssexField.getText().trim().equals("") || sageField.getText().trim().equals("") || scontactField.getText().trim().equals("") || pcodeField.getText().trim().equals("") || acodeField.getText().trim().equals("")){
                    JOptionPane.showMessageDialog(jf,"输入有误,请重试!");
                }else {
                    Integer snum = Integer.parseInt(snumField.getText().trim());
                    String sname = snameField.getText().trim();
                    String ssex = ssexField.getText().trim();
                    Integer sage = Integer.parseInt(sageField.getText().trim());
                    String scontact = scontactField.getText().trim();
                    Integer pcode = Integer.parseInt(pcodeField.getText().trim());
                    Integer acode = Integer.parseInt(acodeField.getText().trim());

                    String str1 = "select * from sta_info where snum = ?";
                    List<Map<String, Object>> maps1 = OperationUtil.selData(str1, snum);

                    String str2 = "select * from sta_info where pcode = ?";
                    List<Map<String, Object>> maps2 = OperationUtil.selData(str2, pcode);

                    String str3 = "select * from sta_info where acode = ?";
                    List<Map<String, Object>> maps3 = OperationUtil.selData(str3, acode);

                    if (!maps1.isEmpty()){
                        JOptionPane.showMessageDialog(jf,"输入的职工号已存在,请重试!");
                    }else if(!maps2.isEmpty()) {
                        JOptionPane.showMessageDialog(jf,"输入的学院代码不存在,请重试!");
                    }else if(!maps3.isEmpty()) {
                        JOptionPane.showMessageDialog(jf,"输入的职称代码不存在,请重试!");
                    }else {
                        String sql = "insert into sta_info values(?,?,?,?,?,?,?)";
                        int count = OperationUtil.inData(sql, snum, sname, ssex, sage, scontact, pcode, acode);
                        if (count!=0){
                            //添加成功
                            JOptionPane.showMessageDialog(jf,"添加成功!");

                        }else {
                            //添加失败
                            JOptionPane.showMessageDialog(jf,"添加失败!");
                        }
                    }
                }
                dispose();
            }
        });


        btnBox.add(addBtn);

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(snumBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(snameBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(ssexBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(sageBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(scontactBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(pcodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(acodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);

    }

}
