package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.util.OperationUtil;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class LabAddDialog extends JDialog {
    final int WIDTH = 700;
    final int HEIGHT = 400;


    public LabAddDialog(JFrame jf, String title, boolean isModel){
        super(jf,title,isModel);
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装代码
        Box lcodeBox = Box.createHorizontalBox();
        JLabel lcodeLable = new JLabel("实验室代码：");
        JTextField lcodeField = new JTextField(15);

        lcodeBox.add(lcodeLable);
        lcodeBox.add(Box.createHorizontalStrut(2));
        lcodeBox.add(lcodeField);

        //组装名称
        Box lnameBox = Box.createHorizontalBox();
        JLabel lnameLable = new JLabel("实验室名称：");
        JTextField lnameField = new JTextField(15);

        lnameBox.add(lnameLable);
        lnameBox.add(Box.createHorizontalStrut(2));
        lnameBox.add(lnameField);

        //组装位置
        Box lsiteBox = Box.createHorizontalBox();
        JLabel lsiteLable = new JLabel("实验室位置：");
        JTextField lsiteField = new JTextField(15);

        lsiteBox.add(lsiteLable);
        lsiteBox.add(Box.createHorizontalStrut(2));
        lsiteBox.add(lsiteField);

        //组装类型
        Box ltypeBox = Box.createHorizontalBox();
        JLabel ltypeLable = new JLabel("实验室类型：");
        JTextField ltypeField = new JTextField(15);

        ltypeBox.add(ltypeLable);
        ltypeBox.add(Box.createHorizontalStrut(2));
        ltypeBox.add(ltypeField);

        //组装职称代码
        Box lsettingBox = Box.createHorizontalBox();
        JLabel lsettingLable = new JLabel("创立时间：");
        JTextField lsettingField = new JTextField(15);

        lsettingBox.add(lsettingLable);
        lsettingBox.add(Box.createHorizontalStrut(10));
        lsettingBox.add(lsettingField);

        //组装等级
        Box llevelBox = Box.createHorizontalBox();
        JLabel llevelLable = new JLabel("等级：");
        JTextField llevelField = new JTextField(15);

        llevelBox.add(llevelLable);
        llevelBox.add(Box.createHorizontalStrut(32));
        llevelBox.add(llevelField);

        //组装办公电话
        Box lcontactBox = Box.createHorizontalBox();
        JLabel lcontactLable = new JLabel("办公电话：");
        JTextField lcontactField = new JTextField(15);

        lcontactBox.add(lcontactLable);
        lcontactBox.add(Box.createHorizontalStrut(10));
        lcontactBox.add(lcontactField);

        //组装学院代码
        Box acodeBox = Box.createHorizontalBox();
        JLabel acodeLable = new JLabel("学院代码：");
        JTextField acodeField = new JTextField(15);

        acodeBox.add(acodeLable);
        acodeBox.add(Box.createHorizontalStrut(10));
        acodeBox.add(acodeField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton addBtn = new JButton("添加");
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (lcodeField.getText().trim().equals("") || lnameField.getText().trim().equals("") || lsiteField.getText().trim().equals("") || ltypeField.getText().trim().equals("") || lsettingField.getText().trim().equals("") || llevelField.getText().trim().equals("")|| lcontactField.getText().trim().equals("") || acodeField.getText().trim().equals("")){
                    JOptionPane.showMessageDialog(jf,"输入有误,请重试!");

                }else {
                    Integer lcode = Integer.parseInt(lcodeField.getText().trim());
                    String lname = lnameField.getText().trim();
                    String lsite = lsiteField.getText().trim();
                    String ltype = ltypeField.getText().trim();
                    String lsetting = lsettingField.getText().trim();
                    String llevel = llevelField.getText().trim();
                    String lcontact = lcontactField.getText().trim();
                    Integer acode = Integer.parseInt(acodeField.getText().trim());

                    Map<String,Object> maps = new HashMap<>();
                    maps.put("lcode",lcode);
                    maps.put("lname",lname);
                    maps.put("lsite",lsite);
                    maps.put("ltype",ltype);
                    maps.put("lsetting",lsetting);
                    maps.put("llevel",llevel);
                    maps.put("lcontact",lcontact);
                    maps.put("acode",acode);

                    String sql = "insert into lab_info values(?,?,?,?,?,?,?,?)";
                    int count = OperationUtil.inData(sql, lcode, lname, lsite, ltype, lsetting, llevel, lcontact,acode);
                    if (count!=0){
                        //添加成功
                        JOptionPane.showMessageDialog(jf,"添加成功!");

                    }else {
                        //添加失败
                        JOptionPane.showMessageDialog(jf,"添加失败!");

                    }
                }
                dispose();

            }
        });


        btnBox.add(addBtn);

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(lcodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(lnameBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(lsiteBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(ltypeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(lsettingBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(llevelBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(lcontactBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(acodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);

    }

}
