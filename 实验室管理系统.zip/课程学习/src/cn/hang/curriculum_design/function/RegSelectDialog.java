package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.entity.Lab_use_reg;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegSelectDialog extends JDialog {
    final int WIDTH = 400;
    final int HEIGHT = 150;

    private JTextField rcodeField;

    private Lab_use_reg reg;

    public RegSelectDialog(JFrame jf, String title, boolean isModel,Lab_use_reg reg){
        super(jf,title,isModel);
        this.reg = reg;
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装代码
        Box rcodeBox = Box.createHorizontalBox();
        JLabel rcodeLable = new JLabel("实验室代码：");
        rcodeField = new JTextField();
        rcodeField.setPreferredSize(new Dimension(200,30));

        rcodeBox.add(rcodeLable);
        rcodeBox.add(Box.createHorizontalStrut(2));
        rcodeBox.add(rcodeField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton selectBtn = new JButton("查询");
        selectBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (!rcodeField.getText().trim().equals("")){
                    System.out.println(rcodeField.getText().trim());
                    Integer rcode = Integer.parseInt(rcodeField.getText().trim());
                    reg.setRcode(rcode);
                }
                dispose();
            }
        });
        //TODO 处理修改的行为
        btnBox.add(selectBtn);


        vBox.add(Box.createVerticalStrut(30));
        vBox.add(rcodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);
    }
}
