package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.util.OperationUtil;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;

public class UserUpdateDialog extends JDialog {
    final int WIDTH = 700;
    final int HEIGHT = 400;
    private String id;
    private Map<String, Object> map;

    private JTextField usernameField;
    private JTextField passwordField;
    private JTextField jurisField;


    public UserUpdateDialog(JFrame jf, String title, boolean isModel, String id){
        super(jf,title,isModel);
        this.id = id;
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装职工号
        Box usernameBox = Box.createHorizontalBox();
        JLabel usernameLable = new JLabel("用户账号：");
        usernameField = new JTextField(20);

        usernameBox.add(usernameLable);
        usernameBox.add(Box.createHorizontalStrut(20));
        usernameBox.add(usernameField);

        //组装姓名
        Box passwordBox = Box.createHorizontalBox();
        JLabel passwordLable = new JLabel("用户密码：");
        passwordField = new JTextField(15);

        passwordBox.add(passwordLable);
        passwordBox.add(Box.createHorizontalStrut(32));
        passwordBox.add(passwordField);

        //组装性别
        Box jurisBox = Box.createHorizontalBox();
        JLabel jurisLable = new JLabel("用嘛权限：");
        jurisField = new JTextField(15);

        jurisBox.add(jurisLable);
        jurisBox.add(Box.createHorizontalStrut(32));
        jurisBox.add(jurisField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton updateBtn = new JButton("修改");
        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (usernameField.getText().trim().equals("") || passwordField.getText().trim().equals("") || jurisField.getText().trim().equals("") ){
                    JOptionPane.showMessageDialog(jf,"输入有误,请重试!");
                }else {
                    String username = usernameField.getText().trim();
                    String password = passwordField.getText().trim();
                    String juris = jurisField.getText().trim();

                    String sql = "update user_list set username = ?,password = ?,juris = ? where username = ?";
                    int count = OperationUtil.upData(sql, username, password, juris, id);
                    if (count!=0){
                        //修改成功
                        JOptionPane.showMessageDialog(jf,"修改成功!");

                    }else {
                        //修改失败
                        JOptionPane.showMessageDialog(jf,"修改失败!");
                    }

                }
                dispose();
            }
        });
        //TODO 处理修改的行为
        btnBox.add(updateBtn);

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(usernameBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(passwordBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(jurisBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);
        //回显数据
        requestData();
    }

    //请求数据
    public void requestData(){
        String sql = "select * from user_list where username = ?";
        List<Map<String, Object>> maps = OperationUtil.selData(sql, id);
        map = maps.get(0);
        System.out.println(map);
        usernameField.setText(map.get("username").toString());
        passwordField.setText(map.get("password").toString());
        jurisField.setText(map.get("juris").toString());
    }
}
