package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.util.OperationUtil;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class TypeAddDialog extends JDialog {
    final int WIDTH = 700;
    final int HEIGHT = 400;

    private JTextField tcodeField;
    private JTextField tnameField;
    private JTextField snumField;

    public TypeAddDialog(JFrame jf, String title, boolean isModel){
        super(jf,title,isModel);
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装类型代码
        Box tcodeBox = Box.createHorizontalBox();
        JLabel tcodeLable = new JLabel("设备类型代码：");
        tcodeField = new JTextField(15);

        tcodeBox.add(tcodeLable);
        tcodeBox.add(Box.createHorizontalStrut(0));
        tcodeBox.add(tcodeField);

        //组装类型名称
        Box tnameBox = Box.createHorizontalBox();
        JLabel tnameLable = new JLabel("设备类型名称：");
        tnameField = new JTextField(15);

        tnameBox.add(tnameLable);
        tnameBox.add(Box.createHorizontalStrut(0));
        tnameBox.add(tnameField);

        //组装管理员
        Box snumBox = Box.createHorizontalBox();
        JLabel snumLable = new JLabel("管理员代码：");
        snumField = new JTextField(15);

        snumBox.add(snumLable);
        snumBox.add(Box.createHorizontalStrut(2));
        snumBox.add(snumField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton addBtn = new JButton("添加");
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (snumField.getText().trim().equals("") || tcodeField.getText().trim().equals("") || tnameField.getText().trim().equals("")){
                    JOptionPane.showMessageDialog(jf,"输入有误,请重试!");
                }else {
                    Integer tcode = Integer.parseInt(tcodeField.getText().trim());
                    String tname = tnameField.getText().trim();
                    Integer snum = Integer.parseInt(snumField.getText().trim());

                    Map<String,Object> maps = new HashMap<>();
                    maps.put("tcode",tcode);
                    maps.put("tname",tname);
                    maps.put("snum",snum);

                    String sql = "insert into lab_dev_type values(?,?,?)";
                    int count = OperationUtil.inData(sql, tcode, tname, snum);
                    if (count!=0){
                        //添加成功
                        JOptionPane.showMessageDialog(jf,"添加成功!");

                    }else {
                        //添加失败
                        JOptionPane.showMessageDialog(jf,"添加失败!");

                    }

                }
                dispose();
            }
        });

        //TODO 处理添加的行为
        btnBox.add(addBtn);

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(tcodeBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(tnameBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(snumBox);
        vBox.add(Box.createVerticalStrut(25));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);
    }
}
