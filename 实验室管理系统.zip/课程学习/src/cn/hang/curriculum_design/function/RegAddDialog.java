package cn.hang.curriculum_design.function;


import cn.hang.curriculum_design.util.OperationUtil;
import cn.hang.curriculum_design.util.ScreenUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class RegAddDialog extends JDialog {
    final int WIDTH = 700;
    final int HEIGHT = 400;

    private JTextField rcodeField;
    private JTextField rtimeField;
    private JTextField rcaseField;
    private JTextField snumField;
    private JTextField lcodeField;

    public RegAddDialog(JFrame jf, String title, boolean isModel){
        super(jf,title,isModel);
        //组装视图
        this.setBounds((ScreenUtils.getScreenWidth()-WIDTH)/2,(ScreenUtils.getScreenHeight()-HEIGHT)/2,WIDTH,HEIGHT);

        Box vBox = Box.createVerticalBox();

        //组装代码
        Box rcodeBox = Box.createHorizontalBox();
        JLabel rcodeLable = new JLabel("登记表代码：");
        rcodeField = new JTextField(20);

        rcodeBox.add(rcodeLable);
        rcodeBox.add(Box.createHorizontalStrut(2));
        rcodeBox.add(rcodeField);

        //组装使用时间
        Box rtimeBox = Box.createHorizontalBox();
        JLabel rtimeLable = new JLabel("使用时间：");
        rtimeField = new JTextField(15);

        rtimeBox.add(rtimeLable);
        rtimeBox.add(Box.createHorizontalStrut(10));
        rtimeBox.add(rtimeField);

        //组装使用情况
        Box rcaseBox = Box.createHorizontalBox();
        JLabel rcaseLable = new JLabel("使用情况：");
        rcaseField = new JTextField(15);

        rcaseBox.add(rcaseLable);
        rcaseBox.add(Box.createHorizontalStrut(10));
        rcaseBox.add(rcaseField);

        //组装使用人
        Box snumBox = Box.createHorizontalBox();
        JLabel snumLable = new JLabel("使用人代码：");
        snumField = new JTextField(15);

        snumBox.add(snumLable);
        snumBox.add(Box.createHorizontalStrut(2));
        snumBox.add(snumField);

        //组装实验室代码
        Box lcodeBox = Box.createHorizontalBox();
        JLabel lcodeLable = new JLabel("实验室代码：");
        lcodeField = new JTextField(15);

        lcodeBox.add(lcodeLable);
        lcodeBox.add(Box.createHorizontalStrut(2));
        lcodeBox.add(lcodeField);

        //组装按钮
        Box btnBox = Box.createHorizontalBox();
        JButton addBtn = new JButton("添加");
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //public String trim()返回一个字符串，其值为此字符串，并删除任何前导和尾随空格。
                //获取用户的录入
                if (rcodeField.getText().trim().equals("") || snumField.getText().trim().equals("") || lcodeField.getText().trim().equals("") || rtimeField.getText().trim().equals("") || rcaseField.getText().trim().equals("")){
                    JOptionPane.showMessageDialog(jf,"输入有误,请重试!");

                }else {
                    Integer rcode = Integer.parseInt(rcodeField.getText().trim());
                    String rtime = rtimeField.getText().trim();
                    String rcase = rcaseField.getText().trim();
                    Integer snum = Integer.parseInt(snumField.getText().trim());
                    Integer lcode = Integer.parseInt(lcodeField.getText().trim());

                    Map<String,Object> maps = new HashMap<>();
                    maps.put("rcode",rcode);
                    maps.put("rtime",rtime);
                    maps.put("rcase",rcase);
                    maps.put("snum",snum);
                    maps.put("lcode",lcode);

                    String sql = "insert into lab_use_reg values(?,?,?,?,?)";
                    int count = OperationUtil.inData(sql, rcode, rtime, rcase, snum, lcode);
                    if (count!=0){
                        //添加成功
                        JOptionPane.showMessageDialog(jf,"添加成功!");
                    }else {
                        //添加失败
                        JOptionPane.showMessageDialog(jf,"添加失败!");
                    }
                }
                dispose();
            }
        });
        //TODO 处理添加的行为
        btnBox.add(addBtn);

        vBox.add(Box.createVerticalStrut(20));
        vBox.add(rcodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(rtimeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(rcaseBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(snumBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(lcodeBox);
        vBox.add(Box.createVerticalStrut(15));
        vBox.add(btnBox);

        //为了左右有间距，在vBox外层封装一个水平的Box，添加间隔
        Box hBox = Box.createHorizontalBox();
        hBox.add(Box.createHorizontalStrut(20));
        hBox.add(vBox);
        hBox.add(Box.createHorizontalStrut(20));

        this.add(hBox);
    }

}
